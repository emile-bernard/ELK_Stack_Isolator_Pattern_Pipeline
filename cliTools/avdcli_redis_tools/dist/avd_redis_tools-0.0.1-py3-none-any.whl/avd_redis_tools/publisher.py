from plumbum import cli
from avdcli import AVDApp
from avd_redis_tools import __version__


class Publisher(AVDApp):
    VERSION = __version__

    def __init__(self, *args):
        super().__init__(*args)

    group = '1 Publisher params'

    my_flag = cli.Flag("--my-flag", default=False, group=group, help='just a flag')

    def main(self):
        super().main()
        print('Flag:', self.my_flag)


if __name__ == "__main__":
    Publisher.run()
