"""
janitor efface des documents d'une liste et garde les plus récents.
publisher prend les éléments d'une liste et les publient sur un channel.
"""
__version__ = '0.0.1'

from .janitor import Janitor
from .publisher import Publisher
