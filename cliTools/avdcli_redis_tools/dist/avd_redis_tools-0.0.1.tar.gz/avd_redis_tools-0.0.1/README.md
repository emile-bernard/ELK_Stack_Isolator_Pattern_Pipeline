# avdcli_redis_tools 
avdcli_redis_tools est un outil utiliser conjointement avec une stack ELK docker pour assurer la cohérence et la performance de l'image redis. Cet outil comporte deux scripts qui scripts, soit : janitor et publisher.

## Scripts
    - janitor efface des documents d'une liste et garde les plus récents.
    - publisher prend les éléments d'une liste et les publient sur un channel.

## General architecture:
![ELK Stack Diagram](https://gitea.avd.ulaval.ca/ember89/stack_elk_proxy_redis/src/commit/24fc55febdc1b1356d192b97c23f827893bbca74/doc/ELK_Stack_Diagram.jpg)

![Persistant Redis Sequence Diagram](https://gitea.avd.ulaval.ca/ember89/stack_elk_proxy_redis/src/commit/b121acdc8227b01386e0845b4a82359a3b89d385/doc/PersistantRedisScriptsSequenceDiagram.jpg)

![ELK Stack Scripts Diagram](https://gitea.avd.ulaval.ca/ember89/stack_elk_proxy_redis/src/commit/6339791fee571c298f5ec991f2555c33bfcb2e43/doc/ELK_Stack_Scripts_Diagram.jpg)

![Persistant Redis Script Sequence Diagram](https://gitea.avd.ulaval.ca/ember89/stack_elk_proxy_redis/src/commit/3037f7bb368295c82a35a698743a2da7d183e03d/doc/PersistantRedisSequenceDiagram.jpg)

### Liens
[Top-5-Redis-Performance-Metrics](https://www.datadoghq.com/pdf/Understanding-the-Top-5-Redis-Performance-Metrics.pdf)

[Official Redis Doc](https://redis.io/)

[Redis desktop manager](https://redisdesktop.com/)

[Redis command line tool](https://redis.io/topics/rediscli)

[Redis with python (redis library documentation)](https://redis-py.readthedocs.io/en/latest/)